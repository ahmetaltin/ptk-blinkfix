import ptk_blinkfix
from prompt_toolkit import PromptSession

PromptSession().prompt(">>> ")
